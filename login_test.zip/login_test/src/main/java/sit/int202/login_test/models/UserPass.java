package sti.int202.login.models;

import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;

public class UserPass {
    private Map<String,String> reg = new HashMap<>();

    public void AddUserPass(String user, String pass) {

        reg.put(user,pass);
    }

    public Boolean getUser(String user){
        if (reg.get(user) == null){ //check ว่า user ที่รับมา มีค่าเป็น null return false
            return false ;
        }
        return true ; //ถ้ามีให้ return true
    }
    public String getPass(String user){

        return reg.get(user); //การ get(user) จะเห็นทั้ง key,value ทำให้ get ค่า password ด้วย
    }
}
