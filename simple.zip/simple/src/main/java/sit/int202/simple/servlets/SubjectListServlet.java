package sit.int202.simple.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import sit.int202.simple.entities.Subject;
import sit.int202.simple.repositories.SubjectRepository;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;


@WebServlet(name = "SubjectListServlet", value = "/subject-list") //URL ที่ทำให้ Web container สามารถเรียกใช้ servlet ได้
public class SubjectListServlet extends HttpServlet {
    private long startTime;

    @Override
    public void destroy() {
        System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        System.out.println("Duration of SubjectListServlet is " +
                (System.currentTimeMillis()-startTime)+ "milli seconds");
        System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    }

    @Override
    public void init() throws ServletException {
        startTime = System.currentTimeMillis();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        SubjectRepository subjectRepository = new SubjectRepository();
        //วิธีส่งข้อมูลต่อไปให้ Controller -> JSP เพื่อทำการ view
        List<Subject> subjects = subjectRepository.findAll();
        request.setAttribute("subjects",subjects); //Request Attribute คือ Request ที่เป็น obj แล้วนำข้อมูลใส่ใน request
        request.getRequestDispatcher("/subject_list.jsp").forward(request,response); // Request Dispatcher คือ ส่งต่อไปให้ JSP เพื่อทำการ view

// การแสดงผลตอบกลับให้ User บน servlet
//        PrintWriter out = response.getWriter();
//        out.println("<html><body>");
//        out.println("<h1>Subject List::</h1></hr>");
//        for (Subject subject : subjectRepository.findAll()) {
//            out.println(subject.getId());
//            out.println(" ");
//            out.println(subject.getTitle());
//            out.println(" ");
//            out.println(subject.getCredit());
//            out.println("</br> ");
//        }
//        out.println("</hr> ");
//        out.println("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
 
