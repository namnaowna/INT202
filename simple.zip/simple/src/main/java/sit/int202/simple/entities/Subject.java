package sit.int202.simple.entities;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class Subject { //เก็บ Data
    private String id;
    private String title;
    private double credit;
}
