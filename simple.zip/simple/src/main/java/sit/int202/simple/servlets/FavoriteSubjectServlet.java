package sit.int202.simple.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

// value = "/favoriteSubject" ได้มาจาก favorite_subject.html ในส่วนของ
// form action="favoriteSubject" เพื่อทำการ mapping หลังจากกด submit
@WebServlet(name = "FavoriteSubjectServlet", value = "/favoriteSubject")
public class FavoriteSubjectServlet extends HttpServlet {

    //อ่านข้อมูลจาก Request เพื่อให้ได้ข้อมูล
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doProcess(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doProcess(request, response);
    }

    //method ที่ลดการ Duplicate กันของ doGet และ doPost
    protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //เป็นการอ่านข้อมูลที่ input เข้ามา
        //สามารถเขียนได้ 2 วิธี
        // วิธีที่ 1
        String name = request.getParameter("name");
        String id = request.getParameter("id");
        //ซึ่งตัว Subjects ที่ได้รับมาเป็น checkbox แต่มีหลาย value
        String subjects[] = request.getParameterValues("subjects");

        //ถ้าต้องการส่งกลับข้อมูลให้ user เป็น html
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1> Your Favorite Subjects </h1><hr>");
        out.println("Student Id : " + id + "<br>");
        out.println("Student Name : " + name + "<br>");
        out.println("YourFavorite Subjects: <br>");
        for (String subject : subjects
        ) {
            out.println("&nbsp &nbsp; - " + subjects + "<br>");
        }

        // วิธีที่ 2 ใช้ map
        Map<String, String[]> params = request.getParameterMap();
        out.println("<br>Request Parameters from Map:<br>");
        out.println("---------------------<br>");
        out.println("Student Id : " + params.get("id")[0] + "<br>");
        out.println("Student Name : " + params.get("id")[0] + "<br>");
        out.println("YourFavorite Subjects: <br>");
        for (String subject : params.get("subjects")) {
            out.println("&nbsp &nbsp; - " + subjects + "<br>");
        }

        out.println("<hr>");
        out.println("<a href='favorite_subject.html'> Back </a>");
        out.println("</body></html>");
    }


}
 
