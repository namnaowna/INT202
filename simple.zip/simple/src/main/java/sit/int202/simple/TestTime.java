package sit.int202.simple;

import javax.xml.crypto.Data;
import java.util.*;

public class TestTime {
    public static void main(String[] args) { //เวลาเริ่มต้นใน com คือ 1 มกราคม 1970 เวลา 7.00
        Date d1 = new Date(1000*60); //1 มกราคม 1970 เวลา 7.01
        Date d2 = new Date(1000*60*60*24); //2 มกราคม 1970 เวลา 7.00
        System.out.println(d1);
        System.out.println(d2);
        System.out.println(System.currentTimeMillis());
        Date toDay = new Date(1697900897911L);
        Date tomorrow = new Date(1697900897911L+1000*60*60*24);
        System.out.println(toDay);
        System.out.println(tomorrow);
    }
}
