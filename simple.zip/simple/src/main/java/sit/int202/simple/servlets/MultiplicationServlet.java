package sit.int202.simple.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

//Controller
@WebServlet(name = "MultiplicationServlet", value = "/multiplication_table")
public class MultiplicationServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //ให้ servlet check ว่าที่ส่งเข้ามา เป็นตัวเลขไหม
        String numberStr = request.getParameter("number");
        if (numberStr == null || numberStr.length() == 0 || !isNumber(numberStr)) {
            request.setAttribute("error", "Invalid number or parameter !!!");//Request Attribute คือ Request ที่เป็น obj แล้วนำข้อมูลใส่ใน request
        }
        request.getRequestDispatcher("/multiplication_table.jsp").forward(request, response); // Request Dispatcher คือ ส่งต่อไปให้ JSP เพื่อทำการ view
    }

    private boolean isNumber(String nStr) {
        for (int i = 0; i < nStr.length(); i++) {
            if (Character.isDigit(nStr.charAt(i))) {
                return false;
            }

        }
        return true;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
 
