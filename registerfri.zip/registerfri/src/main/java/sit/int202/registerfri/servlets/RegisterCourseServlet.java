package sit.int202.registerfri.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import sit.int202.registerfri.models.CourseRegistered;
import sit.int202.registerfri.models.CourseRepository;

import java.io.IOException;
import java.util.Map;


@WebServlet(name = "RegisterCourseServlet", value = "/register")
public class RegisterCourseServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Map<String, String[]> parameterMap = request.getParameterMap(); //get ข้อมูลที่ user ส่งมา เก็บใน parameterMap
        int semester = Integer.valueOf(parameterMap.get("semester")[0]);
        //"semester" มีค่าที่ส่งมาใน HTTP รีเควสต์และมีค่าที่เป็นตัวเลข (เช่น "1", "2", "3" ฯลฯ) โค้ดจะดึงค่าตัวแรก (ดังที่เห็นใน [0]) และแปลงค่านั้นให้อยู่ในรูปของจำนวนเต็ม (integer) โดยใช้ Integer.valueOf() และจะเก็บค่านี้ในตัวแปร semester.

        HttpSession session = request.getSession(); //ขอตะกร้าเพื่อเก็บข้อมูลของ user คนนั้น | parameter ว่าง = true ถ้าเขาพึ่งเคยลงทะเบียนครั้งแรกให้ไปสร้าง session ใหม่ให้
        CourseRegistered courseRegistered = (CourseRegistered)
                session.getAttribute("courseRegistered"); //session อันใหม่ ไม่มีข้อมูลอะไรจะ return null
        if(courseRegistered == null) { //เงื่อนไขหาก session ว่าง
            courseRegistered = new CourseRegistered(); //สร้าง obj เพื่อเก็บ seesion
            session.setAttribute("courseRegistered", courseRegistered); // เอา courseRegistered ลงใน session | เก็บข้อมูลข้าม request
        } else { //เงื่อนไขหาก session ไม่ว่าง
            courseRegistered.removeAllRegisteredCourse(semester); // เคลีย subject ที่เคยลงทั้งหมดใน map
        }

        //เอารหัสวิชา มา search หาวิชา
        for(String subjectId : parameterMap.get("registeredSubjects")) { // loop ลงทะเบียนใหม่ตามที่ user ลง
            courseRegistered.registerSubject(semester, CourseRepository.getSubject(semester,subjectId));
        }
        getServletContext().getRequestDispatcher("/index.jsp").forward(request,response); // forward ไปหา jsp
    }
}
 
