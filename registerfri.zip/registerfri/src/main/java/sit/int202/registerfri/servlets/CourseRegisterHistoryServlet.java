package sit.int202.registerfri.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet(name = "CourseRegisterHistoryServlet", value = "/course-registered-history")
public class CourseRegisterHistoryServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false); //ถ้า seesion ไม่มีค่าอะไร จะ return null
        if (session==null || session.getAttribute("courseRegistered")==null) { //ถ้า session เป็น null คือ User ยังไม่ผ่าน flow การลงทะเบียน
            request.setAttribute("message", "ไม่มีข้อมูล การลงทะเบียน ขอให้ลงทะเบียนก่อน"); //เป็นตัวบอกว่ามีข้อมูลการลงทะเบียนว่ามีหรือไม่มี
        }
        getServletContext().getRequestDispatcher("/user_registered.jsp").forward(request,response); // forward ไปหา jsp
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
