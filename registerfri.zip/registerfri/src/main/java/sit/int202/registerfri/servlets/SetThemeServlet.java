package sit.int202.registerfri.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;


@WebServlet(name = "SetThemeServlet", value = "/set-theme")
public class SetThemeServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/set_theme.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String bgColor = request.getParameter("bgColor"); //ค่าที่ user ส่งเข้ามา
        Cookie ck = new Cookie("bg_color_cookie",bgColor); // สร้าง Cookie เอา bgColor ของ user ลงใน obj cookie
        ck.setMaxAge(8*24*60*60); //set อายุการใช้งาน
        response.addCookie(ck); //ส่งให้ browser เก็บ
        response.sendRedirect("index.jsp"); //response กลับไปให้ user ก่อนเพื่อให้เขาเก็บ cookie แล้วกลับมาหน้า index.jsp
    }
}
 
