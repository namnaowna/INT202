package sit.int202.registerfri.models;

import jakarta.servlet.http.HttpSession;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ViewSupport { //check ว่ามีวิชาไหนที่เคยติ้กไปแล้ว
    public static Map<String,Boolean> getExistSubject(int semester, HttpSession session){
        Map<String,Boolean> existSubjects = new HashMap<>();
        if(session != null & session.getAttribute("courseRegistered") != null) {
            List<Subject> subjects = ((CourseRegistered) session
                    .getAttribute("courseRegistered")).getRegisteredCourse(semester); //ลิส subject ที่อยู่ใน courseRegistered
            if (subjects != null) {
                for (Subject subject : subjects) {
                    existSubjects.put(subject.getSubjectId(), true); //put subject ที่อยู่ใน courseRegistered ขึ้น existSubjects
                }
            }
        }
        return existSubjects;
    }
}
